from . import views
from django.urls import path
#app_name = 'myapp'


urlpatterns=[
    path('register/',views.Register.as_view(),name='register'),
    path('about',views.about,name='about'),
    path('home',views.home,name='home'),   
    
]
